package com.example.snakegame;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatImageButton;

import android.content.DialogInterface;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

public class MainActivity extends AppCompatActivity implements SurfaceHolder.Callback {

    //lista pozicija zmije / duzine zmije
    private final List<SnakePoints> snakePointsList = new ArrayList<>();



    private SurfaceView surfaceView;
    private TextView scoreTV;

    //crtanje zmije
    private SurfaceHolder surfaceHolder;



    //pozicija kretnje zmije.Navodi moraju biti right,left,top i bottom.
    //Po default zmija će ići desno
    private String movingPosition = "right";

    //rezultat
    private int score = 0;

    //duzina zmije / snake point
    //može se postavljati nova vrijednost kako bi zmija bila veća
    private static final int pointSize = 28;

    //početno stanje zmijinog tijela/repa
    private static final int defaultTalePoints = 3;

    //boja zmije
    private static final int snakeColor = Color.YELLOW;

    //brzina kretanja zmije. Vrijednosti moraju biti izmedu 1 - 1000
    private static final int snakeMovingSpeed = 800;



    //random points positions cordinates on the surfaceView
    private int positionX,positionY;

    //timer za kretanje zmije / nova pozicija zmije nakog specificnog vremena (snakeMovingSpeed)
    private Timer timer;

    //canvas za crtanje zmije i prikaz na površini
    private Canvas canvas = null;

    //point color / single point boja zmije
    private Paint pointColor = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // dobivanje surfaceview i TextView iz xml file-a
        surfaceView = findViewById(R.id.surfaceView);
        scoreTV = findViewById(R.id.scoreTV);

        // uzimanje slika iz xml file-a
        final AppCompatImageButton topBtn = findViewById(R.id.topBtn);
        final AppCompatImageButton leftBtn = findViewById(R.id.leftBtn);
        final AppCompatImageButton rightBtn = findViewById(R.id.rightBtn);
        final AppCompatImageButton bottomBtn = findViewById(R.id.bottomBtn);

        // dodavanje callback-a za surfaceview
        surfaceView.getHolder().addCallback(this);


        topBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //provjera da prethodni korak nije bottom.Zmija se ne moze kretati.
                //Primjer ako se zmija kreće prema dnu ne moze direktno krenuti prema vrhu
                //Zmija se mora kretati lijevo ili desno prvo pa onda prema vrhu
                if(!movingPosition.equals("bottom")){
                    movingPosition = "top";
                }

            }
        });

        leftBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(!movingPosition.equals("right")){
                    movingPosition = "left";
                }

            }
        });

        rightBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(!movingPosition.equals("left")){
                    movingPosition = "right";
                }

            }
        });

        bottomBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(!movingPosition.equals("top")){
                    movingPosition = "bottom";
                }

            }
        });

    }

    @Override
    public void surfaceCreated(@NonNull SurfaceHolder surfaceHolder) {

        this.surfaceHolder = surfaceHolder;

        init();
    }

    @Override
    public void surfaceChanged(@NonNull SurfaceHolder surfaceHolder, int i, int i1, int i2) {

    }

    @Override
    public void surfaceDestroyed(@NonNull SurfaceHolder surfaceHolder) {

    }

    private void init(){


        //očisti poziciju zmije / duzinu zmije
        snakePointsList.clear();

        //postavljanje početnog rezultata na 0
        scoreTV.setText("0");

        //postaviti rezultat na 0
        score = 0;

        //postavljanje početne pozicije kretnje
        movingPosition = "right";

        //početna pozicija zmijine kretnje  na ekranu
        int startPositionX = (pointSize) * defaultTalePoints;

        //postavljanje default duzine zmije / points
        for (int i = 0; i < defaultTalePoints; i++){



            //dodavanje bodova za zmijin rep
            SnakePoints snakePoints = new SnakePoints(startPositionX,pointSize);
            snakePointsList.add(snakePoints);

            //povećanje vrijednosti za idući poen
            startPositionX = startPositionX - (pointSize * 2);

        }

        //dodaje random poene na ekranu koje će zmija pojesti
        addPoint();

        //start moving snake / pokretanje igre
        moveSnake();
    }

    private void addPoint(){

        //dodavanje dimenzija kako bi se zbrojili poeni koji se pojedu na ekranu
        int surfaceWidth = surfaceView.getWidth() - (pointSize * 2);
        int surfaceHeight = surfaceView.getHeight() -(pointSize * 2);

        int randomXPosition = new Random().nextInt(surfaceWidth / pointSize);
        int randomYPosition = new Random().nextInt(surfaceHeight / pointSize);

        //provjera jel randomXPosition jednaka ili na nekoj cudnoj poziciji.Treba nam samo jednak broj.
        if ((randomXPosition % 2) != 0){
            randomXPosition = randomXPosition + 1;

        }

        if ((randomYPosition % 2) != 0){
            randomYPosition = randomYPosition + 1;
        }

        positionX = (pointSize * randomXPosition) + pointSize;
        positionY = (pointSize * randomYPosition) + pointSize;

    }

    private void moveSnake(){

        timer = new Timer();
        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {

                //dodjela pozicije glave
                int headPositionX = snakePointsList.get(0).getPositionX();
                int headPositionY = snakePointsList.get(0).getPositionY();


                //provjera jel zmija pojela poen
                if (headPositionX == positionX && positionY == headPositionY){

                    //povećanje zmije nakon jedenja poena
                    growSnake();

                    //dodavanje poena na ekranu
                    addPoint();

                }

                //provjera koji dio se zmije kreće
                switch (movingPosition){
                    case "right":

                        //kretnja zmijine glave u desno
                        snakePointsList.get(0).setPositionX(headPositionX + (pointSize * 2));
                        snakePointsList.get(0).setPositionY(headPositionY);
                        break;

                    case "left":
                        //kretnja zmijine glave u lijevo
                        snakePointsList.get(0).setPositionX(headPositionX - (pointSize * 2));
                        snakePointsList.get(0).setPositionY(headPositionY);
                        break;

                    case "top":
                        //kretnja zmijine glave gore
                        snakePointsList.get(0).setPositionX(headPositionX);
                        snakePointsList.get(0).setPositionY(headPositionY - (pointSize * 2));
                        break;
                    case "bottom":
                        //kretnja zmijine glave dolje
                        snakePointsList.get(0).setPositionX(headPositionX);
                        snakePointsList.get(0).setPositionY(headPositionY + (pointSize * 2));
                        break;
                }

                //provjera jel igra game over.Zmija dodirnula ivicu ili samu sebe.
                if (checkGameOver(headPositionX, headPositionY)){

                    //zaustavljanje tajmera / zaustavljanje kretnje zmije
                    timer.purge();
                    timer.cancel();

                    //Prikaz Game Over dijaloga
                    AlertDialog.Builder builder =  new AlertDialog.Builder(MainActivity.this);
                    builder.setMessage("Your Score = " +score);
                    builder.setTitle("Game Over");
                    builder.setCancelable(false);
                    builder.setPositiveButton("Start Again", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {

                            //restart game / re init data
                            init();

                        }
                    });

                    //timer radi u pozadini
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            builder.show();

                        }
                    });
                }

                else{

                    //zaključavanje canvas na površini da se crta na njoj
                    canvas = surfaceHolder.lockCanvas();
                    //čišćenje canvas sa bijelom bojom
                    canvas.drawColor(Color.WHITE, PorterDuff.Mode.CLEAR);

                    //nova pozicija glave zmije
                    canvas.drawCircle(snakePointsList.get(0).getPositionX(), snakePointsList.get(0).getPositionY(), pointSize,createPaintColor());

                    //crtanje random kruga na ekranu koji će se pojesti
                    canvas.drawCircle(positionX,positionY,pointSize,createPaintColor());

                    //praćenje drugih poena
                    for (int i = 1; i < snakePointsList.size(); i++){

                        int getTempPositionX = snakePointsList.get(i).getPositionX();
                        int getTempPositionY = snakePointsList.get(i).getPositionY();

                        //kretnja poena na glavi
                        snakePointsList.get(i).setPositionX(headPositionX);
                        snakePointsList.get(i).setPositionY(headPositionY);
                        canvas.drawCircle(snakePointsList.get(i).getPositionX(), snakePointsList.get(i).getPositionY(),pointSize,createPaintColor());

                        //nova pozicija glave
                        headPositionX = getTempPositionX;
                        headPositionY = getTempPositionY;

                    }

                    //otključavanje canvas za crtanje na površini
                    surfaceHolder.unlockCanvasAndPost(canvas);

                }
            }
        }, 1000- snakeMovingSpeed,  1000- snakeMovingSpeed);
    }

    private void growSnake(){


        //kreiranje novog poena za zmiju
        SnakePoints snakePoints = new SnakePoints(0,0);

        //dodavanje poena repu od zmije
        snakePointsList.add(snakePoints);


        //dodavanje poena
        score++;

        //postavljanje poena na TextViews
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                scoreTV.setText(String.valueOf(score));
            }
        });

    }
    private boolean checkGameOver(int headPositionX, int headPositionY){

        boolean gameOver = false;

        //provjera jel glava zmije dodirnula ivicu
        if (snakePointsList.get(0).getPositionX() < 0  ||
        snakePointsList.get(0).setPositionY() < 0 ||
                snakePointsList.get(0).getPositionX() >= surfaceView.getWidth() ||
                snakePointsList.get(0).getPositionY() >= surfaceView.getHeight())
        {
            gameOver = true;

        }

        else {

            //provjeriti jel zmija dotaknula samu sebe

            for (int i = 1; i < snakePointsList.size(); i++){

                if (headPositionX == snakePointsList.get(i).getPositionX() &&
                        headPositionY == snakePointsList.get(i).getPositionY()) {
                    gameOver = true;
                    break;
                }
            }
        }
        return gameOver;
    }

    private Paint createPaintColor(){
        if (pointColor == null){

            pointColor = new Paint();
            pointColor.setColor(snakeColor);
            pointColor.setStyle(Paint.Style.FILL);
            pointColor.setAntiAlias(true);




        }



        return pointColor;
    }

}